from flask import render_template, request, jsonify, Flask

import requests
import pytz
import datetime
import json

app = Flask(__name__)

app.config["SECRET_KEY"] = "5791628bb0b13ce0c676dfde280ba245"

google_api_url = "https://maps.googleapis.com/maps/api/geocode/json"
google_api_key = "AIzaSyBq_oD-Y35Xtj-1rpjGlOlsa_E1oA7PQmM"
tomorrow_apikey = "Jy9WbYrOwTnCAiS7XJT4Qex23PIMsqgb"
fields_1d = ["temperatureMin", "temperatureMax", "windSpeed", "weatherCode", "precipitationType",
             "precipitationProbability", "sunriseTime", "sunsetTime", "humidity", "visibility"]
fields_5days = ["temperature", "windSpeed", "humidity", "pressureSeaLevel", "windDirection"]

fields_current = ["temperature", "windSpeed",
                  "humidity", "pressureSeaLevel", "uvIndex", "weatherCode", "visibility",
                  "cloudCover"]

ipInfo_token = "85da4d0e3ab8c6"


@app.route("/")
def home():
    """ Home Page """
    return render_template("index.html")


@app.route("/hours", methods=["GET"])
def hours():
    url = "https://api.tomorrow.io/v4/timelines"
    auto_detect = request.args.get("detect")
    if auto_detect is not None and auto_detect == "true":
        ip = request.remote_addr
        loc, location = get_location_by_ip(ip)
    else:
        street = request.args.get("street")
        city = request.args.get("city")
        state = request.args.get("state")
        loc, location = get_location(street, city, state)
    if loc is None or location is None:
        return jsonify({"error": "can not get weather info"})
    utc_tz = pytz.timezone('America/Los_Angeles')
    start = datetime.datetime.now(tz=utc_tz).isoformat()
    end = (datetime.datetime.now(tz=utc_tz) + datetime.timedelta(days=4.5)).isoformat()

    querystring = {"units": "imperial", "timesteps": "1h",
                   "timezone": "America/Los_Angeles", "apikey": tomorrow_apikey,
                   "location": loc, "startTime": start, "endTime": end, "fields": ",".join(fields_5days)}

    headers = {"Accept": "application/json"}

    response = requests.request("GET", url, headers=headers, params=querystring)

    obj = json.loads(response.text)
    result = obj["data"]["timelines"][0]["intervals"]

    res = app.response_class(
        response=json.dumps(result),
        mimetype='application/json',
        headers={'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'accept, content-type',
                 'Access-Control-Allow-Method': 'GET'},
        status=200
    )
    return res


@app.route("/weather", methods=["GET"])
def weather():
    auto_detect = request.args.get("detect")
    if auto_detect is not None and auto_detect == "true":
        ip = request.remote_addr
        loc, location = get_location_by_ip(ip)
    else:
        street = request.args.get("street")
        city = request.args.get("city")
        state = request.args.get("state")
        loc, location = get_location(street, city, state)
    if loc is None or location is None:
        return jsonify({"error": "can not get weather info"})
    result = get_tomorrow_weather_info(loc, location)
    if result is None:
        return jsonify({"error": "can not get weather info"})
    response = app.response_class(
        response=json.dumps(result),
        mimetype='application/json',
        headers={'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'accept, content-type',
                 'Access-Control-Allow-Method': 'GET'},
        status=200
    )
    return response


def get_location_by_ip(ip):
    if ip == "127.0.0.1":
        ip = "180.149.134.141"
    url = "https://ipinfo.io/" + ip
    param = {"token": ipInfo_token}
    resp = requests.get(url, params=param)
    if resp.status_code == 200:
        json_obj = json.loads(resp.text)
        return json_obj["loc"], json_obj['city'] + "," + json_obj['region'] + "," + json_obj['country']
    else:
        return None


def get_location(street, city, state):
    address = []
    for i in street.split(" "):
        address.append(i)
    for j in city.split(" "):
        address.append(j)
    for k in state.split(" "):
        address.append(k)
    param = {"address": "+".join(address), "key": google_api_key}
    resp = requests.get(google_api_url, params=param)
    json_obj = json.loads(resp.text)
    if json_obj["status"] == "OK":
        ret = str(json_obj["results"][0]["geometry"]["location"]["lat"]) + "," + \
              str(json_obj["results"][0]["geometry"]["location"]["lng"])
        return ret, json_obj["results"][0]["formatted_address"]
    else:
        return None


def get_tomorrow_weather_info(loc, location):
    result = {"location": location}
    url = "https://api.tomorrow.io/v4/timelines"
    querystring = {"units": "imperial", "timesteps": "current",
                   "timezone": "America/Los_Angeles", "apikey": tomorrow_apikey,
                   "location": loc, "fields": ",".join(fields_current)}
    headers = {"Accept": "application/json"}
    resp_current = requests.get(url, headers=headers, params=querystring)
    if resp_current.status_code != 200:
        return None
    current_obj = json.loads(resp_current.text)
    querystring = {"units": "imperial", "timesteps": "1d",
                   "timezone": "America/Los_Angeles", "apikey": tomorrow_apikey,
                   "location": loc, "fields": ",".join(fields_1d)}
    resp_1d = requests.get(url, headers=headers, params=querystring)
    if resp_1d.status_code != 200:
        return None
    _15day_obj = json.loads(resp_1d.text)
    result["15day"] = _15day_obj["data"]["timelines"][0]["intervals"]

    result["current"] = current_obj["data"]["timelines"][0]["intervals"][0]

    result["current"]["startTime"] = result["current"]["startTime"][:10]

    for item in result["15day"]:
        item["startTime"] = item["startTime"][:10]

    return result





if __name__ == "__main__":
    app.run(debug=False)
