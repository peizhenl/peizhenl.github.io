Run this code in localhost both use npm install & npm start:

Open backend file
npm install
npm start


Open frontend file
npm install
npm start

Open localhost:xxxx showed in frontend file in Google browser