import {Component} from '@angular/core';
import {HttpClient} from '@angular/common/http'
import * as Highcharts from 'highcharts';
import highchartsMore from 'highcharts/highcharts-more'
import WindBarb from 'highcharts/modules/windbarb'
import {J} from "@angular/cdk/keycodes";

export interface User {
  name: string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  zoom: number = 16;
  center: any;
  // initial center position for the map
  lat: number = 51.673858;
  lng: number = 7.815982;
  minMaxHighcharts: any = Highcharts;
  minMaxOptions: any = {
    chart: {
      type: 'arearange',
      zoomType: 'x',
      scrollablePlotArea: {
        minWidth: 600,
        scrollPositionX: 1
      }
    },
    plotOptions: {
      series: {
        fillColor: {
          linearGradient: [0, 0, 0, 400],
          stops: [
            [0, '#F5AB3B'],
            [1, Highcharts.color(this.minMaxHighcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
          ]
        }
      }
    },
    title: {
      text: 'Temperature Ranges (Min, Max)'
    },
    xAxis: {
      type: 'datetime',
      accessibility: {
        rangeDescription: 'Range: Jan 1st 2017 to Dec 31 2017.'
      },
      crosshair: {
        width: 1,
        color: 'grey',
        dashStyle: 'shortdot'
      }
    },
    yAxis: {
      title: {
        text: null
      }
    },
    legend: {
      enabled: false
    },
    series: [{
      name: 'Temperatures',
      data: []
    }],
    tooltip: {
      valueSuffix: '℉'
    }
  }
  hourHighcharts: any = Highcharts;
  hourOptions: any = {
    chart: {
      marginBottom: 70,
      marginRight: 40,
      marginTop: 50,
      plotBorderWidth: 1,
      height: 400,
      alignTicks: false,
      scrollablePlotArea: {
        minWidth: 720
      }
    },

    defs: {
      patterns: [{
        id: 'precipitation-error',
        path: {
          d: [
            'M', 3.3, 0, 'L', -6.7, 10,
            'M', 6.7, 0, 'L', -3.3, 10,
            'M', 10, 0, 'L', 0, 10,
            'M', 13.3, 0, 'L', 3.3, 10,
            'M', 16.7, 0, 'L', 6.7, 10
          ].join(' '),
          stroke: '#68CFE8',
          strokeWidth: 1
        }
      }]
    },

    title: {
      text: 'Hourly Weather ( For Next 5 Days )',
    },

    credits: {
      text: 'Forecast from '
    },

    tooltip: {
      shared: true,
      useHTML: true,
      headerFormat:
        '<small>{point.x:%A, %b %e, %H:%M} - {point.point.to:%H:%M}</small><br>' +
        '<b>{point.point.symbolName}</b><br>'
    },

    xAxis: [{ // Bottom X axis
      type: 'datetime',
      tickInterval: 4 * 36e5, // two hours
      minorTickInterval: 2 * 36e5, // one hour
      tickLength: 0,
      gridLineWidth: 1,
      gridLineColor: 'rgba(128, 128, 128, 0.1)',
      startOnTick: false,
      endOnTick: false,
      minPadding: 0,
      maxPadding: 0,
      offset: 30,
      showLastLabel: true,
      labels: {
        format: '{value:%H}'
      },
      crosshair: true
    }, { // Top X axis
      linkedTo: 0,
      type: 'datetime',
      tickInterval: 24 * 3600 * 1000,
      labels: {
        format: '{value:<span style="font-size: 12px; font-weight: bold">%a</span> %b %e}',
        align: 'left',
        x: 3,
        y: -5
      },
      opposite: true,
      tickLength: 20,
      gridLineWidth: 1
    }],

    yAxis: [{ // temperature axis
      title: {
        text: null
      },
      labels: {
        format: '{value}°',
        style: {
          fontSize: '10px'
        },
        x: -3
      },
      plotLines: [{ // zero plane
        value: 0,
        color: '#BBBBBB',
        width: 1,
        zIndex: 2
      }],
      maxPadding: 0.3,
      minRange: 8,
      tickInterval: 1,
      gridLineColor: 'rgba(128, 128, 128, 0.1)'

    }, { // precipitation axis
      title: {
        text: null
      },
      labels: {
        enabled: false
      },
      gridLineWidth: 0,
      tickLength: 0,
      minRange: 10,
      min: 0

    }, { // Air pressure
      allowDecimals: false,
      title: { // Title on top of axis
        text: 'hPa',
        offset: 0,
        align: 'high',
        rotation: 0,
        style: {
          fontSize: '10px',
          color: this.hourHighcharts.getOptions().colors[0]
        },
        textAlign: 'left',
        x: 3
      },
      labels: {
        style: {
          fontSize: '8px',
          color: this.hourHighcharts.getOptions().colors[1]
        },
        y: 2,
        x: 3
      },
      gridLineWidth: 0,
      opposite: true,
      showLastLabel: false
    }],

    legend: {
      enabled: false
    },

    plotOptions: {
      series: {
        pointPlacement: 'between'
      }
    }
  }


  public states = [
    {'text': 'Alabama', 'value': 'AL'}, {'text': 'Alaska', 'value': 'AK'}, {
      'text': 'American Samoa',
      'value': 'AS'
    }, {'text': 'Arizona', 'value': 'AZ'}, {'text': 'Arkansas', 'value': 'AR'}, {
      'text': 'California',
      'value': 'CA'
    }, {'text': 'Colorado', 'value': 'CO'}, {'text': 'Connecticut', 'value': 'CT'}, {
      'text': 'Delaware',
      'value': 'DE'
    }, {'text': 'District Of Columbia', 'value': 'DC'}, {
      'text': 'Federated States Of Micronesia',
      'value': 'FM'
    }, {'text': 'Florida', 'value': 'FL'}, {'text': 'Georgia', 'value': 'GA'}, {
      'text': 'Guam',
      'value': 'GU'
    }, {'text': 'Hawaii', 'value': 'HI'}, {'text': 'Idaho', 'value': 'ID'}, {
      'text': 'Illinois',
      'value': 'IL'
    }, {'text': 'Indiana', 'value': 'IN'}, {'text': 'Iowa', 'value': 'IA'}, {
      'text': 'Kansas',
      'value': 'KS'
    }, {'text': 'Kentucky', 'value': 'KY'}, {'text': 'Louisiana', 'value': 'LA'}, {
      'text': 'Maine',
      'value': 'ME'
    }, {'text': 'Marshall Islands', 'value': 'MH'}, {'text': 'Maryland', 'value': 'MD'}, {
      'text': 'Massachusetts',
      'value': 'MA'
    }, {'text': 'Michigan', 'value': 'MI'}, {'text': 'Minnesota', 'value': 'MN'}, {
      'text': 'Mississippi',
      'value': 'MS'
    }, {'text': 'Missouri', 'value': 'MO'}, {'text': 'Montana', 'value': 'MT'}, {
      'text': 'Nebraska',
      'value': 'NE'
    }, {'text': 'Nevada', 'value': 'NV'}, {'text': 'New Hampshire', 'value': 'NH'}, {
      'text': 'New Jersey',
      'value': 'NJ'
    }, {'text': 'New Mexico', 'value': 'NM'}, {'text': 'New York', 'value': 'NY'}, {
      'text': 'North Carolina',
      'value': 'NC'
    }, {'text': 'North Dakota', 'value': 'ND'}, {'text': 'Northern Mariana Islands', 'value': 'MP'}, {
      'text': 'Ohio',
      'value': 'OH'
    }, {'text': 'Oklahoma', 'value': 'OK'}, {'text': 'Oregon', 'value': 'OR'}, {
      'text': 'Palau',
      'value': 'PW'
    }, {'text': 'Pennsylvania', 'value': 'PA'}, {'text': 'Puerto Rico', 'value': 'PR'}, {
      'text': 'Rhode Island',
      'value': 'RI'
    }, {'text': 'South Carolina', 'value': 'SC'}, {'text': 'South Dakota', 'value': 'SD'}, {
      'text': 'Tennessee',
      'value': 'TN'
    }, {'text': 'Texas', 'value': 'TX'}, {'text': 'Utah', 'value': 'UT'}, {
      'text': 'Vermont',
      'value': 'VT'
    }, {'text': 'Virgin Islands', 'value': 'VI'}, {'text': 'Virginia', 'value': 'VA'}, {
      'text': 'Washington',
      'value': 'WA'
    }, {'text': 'West Virginia', 'value': 'WV'}, {'text': 'Wisconsin', 'value': 'WI'}, {
      'text': 'Wyoming',
      'value': 'WY'
    }];
  public filterOptions: any;
  public useCurrentLocation = false;
  public shareText = '';
  public forms: any = {
    street: "",
    city: "",
    state: "-1",
  };
  public hasError = false;
  public searchStatus = 0;//0 not search 1:searching 2:end
  public weatherData: any = [];
  public hourWeatherData: any;
  public currentWeather: any;
  public isFavorite = false;
  public currentAction = 'search';
  public favoriteData: any = [];
  public currentQuery = {
    id: '',
    state: '',
    city: '',
    country: '',
    lat: '',
    lon: '',
    locationString: ''
  }


  constructor(public http: HttpClient) {
    let favoriteData: any = localStorage.getItem('favoriteData');
    if (favoriteData) this.favoriteData = JSON.parse(favoriteData)
    else this.favoriteData = [];
    highchartsMore(this.minMaxHighcharts)
    WindBarb(this.hourHighcharts)
  }


  drawHourChart() {
    const temp = [], pressure = [], humility = [], wind = [];
    let i = 0;
    for (let item of this.hourWeatherData) {
      temp.push([item.timestamp, item.values.temperature])
      pressure.push([item.timestamp, Math.floor(item.values.pressureSeaLevel)])
      humility.push([item.timestamp, item.values.humidity])
      if (i % 4 == 0)
        wind.push([item.timestamp, item.values.windSpeed, item.values.windDirection])
      i++;
    }
    this.hourOptions.series = [
      {
        name: 'Temperature',
        type: 'spline',
        data: temp,
        marker: {
          enabled: false,
          states: {
            hover: {
              enabled: true
            }
          }
        },
        tooltip: {
          pointFormat: '<span style="color:{point.color}">\u25CF</span> ' +
            '{series.name}: <b>{point.y}℉</b><br/>'
        },
        zIndex: 1,
        color: '#FF3333',
        negativeColor: '#48AFE8'
      },
      {
        name: 'Humility',
        type: 'column',
        color: '#96cdfa',
        yAxis: 1,
        data: humility,
        groupPadding: 0,
        pointPadding: 0,
        grouping: false,
        dataLabels: {
          filter: {
            operator: '>',
            property: 'y',
            value: 0
          },
          style: {
            fontSize: '8px',
            color: 'gray'
          }
        },
        tooltip: {
          valueSuffix: '%'
        }
      },
      {
        name: 'Air pressure',
        color: "#ff9900",
        data: pressure,
        marker: {
          enabled: false
        },
        shadow: false,
        tooltip: {
          valueSuffix: ' inHg'
        },
        dashStyle: 'shortdot',
        yAxis: 2
      },
      {
        name: 'Wind',
        id: 'windbarb',
        type: 'windbarb',
        data: wind,
        color: '#FF3333',
        lineWidth: 1.5,
        vectorLength: 18,
        yOffset: -15,
        tooltip: {
          valueSuffix: ' m/s'
        }
      }]
  }

  drawMinMaxChart() {
    const arr = []
    for (let i = 0; i < this.weatherData.length; i++) {
      const item = this.weatherData[i]
      arr[i] = [item.timestamp, item.values.temperatureMin, item.values.temperatureMax]
    }
    // @ts-ignore
    this.minMaxOptions.series = [{name: 'Temperature', data: arr}]
  }

  autoComplete(form: any) {
    if (form.city) {
      const url = `https://hw8api-330410.uc.r.appspot.com/predict?input=${form.city}`
      this.http.get(url).subscribe((res: any) => {
        this.filterOptions = res;
      })
    }
  }

  fillState(option: any) {
    this.forms.state = option.state;
  }

  checkIsValid() {
    return this.forms.street && this.forms.city && this.forms.state && this.forms.state != "-1"
  }

  getLocationByIp() {
    const url = "http://ip-api.com/json";
    return this.http.get(url)
  }

  getWeatherData(lat: any, lng: any) {
    const url = `https://hw8api-330410.uc.r.appspot.com/weather?location=${lat},${lng}`;
    return this.http.get(url)
  }

  handleClickWeather(weather: any) {
    this.currentWeather = weather;
    this.shareText = this.share(this.currentQuery.city, this.currentQuery.state, weather.startTime, weather.values.temperature, weather.weather_text)
  }

  getGeoCode() {
    const url = `https://hw8api-330410.uc.r.appspot.com/geocode?city=${this.forms.city}&state=${this.forms.state}&street=${this.forms.street}`;
    return this.http.get(url)
  }

  getHourWeatherData(lat: any, lon: any) {
    const url = `https://hw8api-330410.uc.r.appspot.com/weather?location=${lat},${lon}&fields=temperature,humidity,windSpeed,pressureSeaLevel,windDirection&timeStep=1h`
    return this.http.get(url)
  }

  setFavorite(favorite: any) {
    let id = `${favorite.lat} ${favorite.lon}`
    let find = false;
    for (let i = 0; i < this.favoriteData.length; i++) {
      let item = this.favoriteData[i];
      if (item.id === id) {
        this.favoriteData.splice(i, 1);
        find = true;
        this.isFavorite = this.currentQuery.id !== id;
        break;
      }
    }
    if (!find) {
      this.favoriteData.push({
        lon: this.currentQuery.lon,
        lat: this.currentQuery.lat,
        locationString: this.currentQuery.locationString,
        state: this.currentQuery.state,
        city: this.currentQuery.city,
        id: this.currentQuery.id
      })
      this.isFavorite = true;
    }
    localStorage.setItem('favoriteData', JSON.stringify(this.favoriteData))

  }

  checkIsFavorite() {
    return this.favoriteData.filter((item: any) => {
      return item.id === this.currentQuery.id
    }).length > 0
  }

  setCurrentQuery(city: any, state: any, lat: any, lon: any, locationString: any) {
    this.currentQuery.city = city;
    this.currentQuery.state = state;
    this.currentQuery.lat = lat
    this.currentQuery.lon = lon;
    this.currentQuery.locationString = locationString
    this.currentQuery.id = `${lat} ${lon}`
  }

  handleWeatherData(lat: any, lon: any) {
    console.log(this.favoriteData)
    this.center = {lat: lat, lng: lon}
    this.getWeatherData(lat, lon).subscribe((weatherData: any) => {
      if (weatherData.message) {
        this.hasError = true;
      } else {
        this.isFavorite = this.checkIsFavorite()
        this.weatherData = weatherData.data
        this.drawMinMaxChart();
      }
      this.searchStatus = 2;
    })
    this.getHourWeatherData(lat, lon).subscribe((data: any) => {
      if (data.message) {
        this.hasError = true;
      } else {
        this.hourWeatherData = data.data;
        this.drawHourChart()
      }
      this.searchStatus = 2;
    })
  }

  share(city: any, state: any, date: any, temp: any, weather: any) {
    return `The temperature in ${city}, ${state} on ${date} is ${temp}°F. The weather conditions are ${weather}`
  }

  clearData() {
    this.forms.city = "";
    this.forms.state = "";
    this.forms.street = "";
    this.searchStatus = 0;
    this.useCurrentLocation = false;
  }

  favClick(favorite: any) {
    this.currentQuery = JSON.parse(JSON.stringify(favorite));
    this.getData(1);
  }

  getData(fromCurrentQuery = 0) {

    this.hasError = false;
    this.currentAction = 'search';
    this.searchStatus = 1;
    if (fromCurrentQuery == 1) {
      this.handleWeatherData(this.currentQuery.lat, this.currentQuery.lon);
    } else {
      if (this.useCurrentLocation) {
        this.getLocationByIp().subscribe((res: any) => {
          //set current query information
          let locationString = `${res.city} ${res.countryCode}`;
          this.setCurrentQuery(res.city, res.countryCode, res.lat, res.lon, locationString);
          this.handleWeatherData(res.lat, res.lon)
        })
      } else {
        this.getGeoCode().subscribe((res: any) => {
          let locationString = `${this.forms.street} ${this.forms.city} ${this.forms.state}`;
          this.setCurrentQuery(this.forms.city, this.forms.state, res.lat, res.lng, locationString);
          this.handleWeatherData(res.lat, res.lng);
        })
      }
    }

  }


}
