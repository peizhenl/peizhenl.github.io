import express from 'express'
import cors from 'cors'
import request from 'request'
import moment from 'moment'

const app = express();

const API_KEYS = {
    "weather": "4KRrfC5evWuTbSrIKAIt9esP0tBfDdlQ",
    "googleMap": "AIzaSyAmq6zgFx8wkyhYjc1nbUZ6qbIO7hMf4UY",
    "geoCode": "AIzaSyBq_oD-Y35Xtj-1rpjGlOlsa_E1oA7PQmM"
};
const WEATHER_FIELDS = ['temperature', 'temperatureApparent', 'temperatureMin', 'temperatureMax', 'windSpeed',
    'windDirection', 'humidity', 'pressureSeaLevel', 'weatherCode', 'precipitationProbability',
    'precipitationType', 'sunriseTime', 'sunsetTime', 'visibility', 'moonPhase', 'cloudCover', 'weatherCode']

const STATE = {
    "AL": "Alabama",
    "AK": "Alaska",
    "AS": "American Samoa",
    "AZ": "Arizona",
    "AR": "Arkansas",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DE": "Delaware",
    "DC": "District Of Columbia",
    "FM": "Federated States Of Micronesia",
    "FL": "Florida",
    "GA": "Georgia",
    "GU": "Guam",
    "HI": "Hawaii",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "IA": "Iowa",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "ME": "Maine",
    "MH": "Marshall Islands",
    "MD": "Maryland",
    "MA": "Massachusetts",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MS": "Mississippi",
    "MO": "Missouri",
    "MT": "Montana",
    "NE": "Nebraska",
    "NV": "Nevada",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NY": "New York",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "MP": "Northern Mariana Islands",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PW": "Palau",
    "PA": "Pennsylvania",
    "PR": "Puerto Rico",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VT": "Vermont",
    "VI": "Virgin Islands",
    "VA": "Virginia",
    "WA": "Washington",
    "WV": "West Virginia",
    "WI": "Wisconsin",
    "WY": "Wyoming"
};
const WEATHER_CODE_DICT = {
    '0': {'text': 'Unknown', 'code': 'unknown'},
    '1000': {'text': 'Clear', 'code': 'clear_day'},
    '1001': {'text': 'Cloudy', 'code': 'cloudy'},
    '1100': {'text': 'Mostly Clear', 'code': 'mostly_clear_day'},
    '1101': {'text': 'Partly Cloudy', 'code': 'partly_cloudy_day'},
    '1102': {'text': 'Mostly Cloudy', 'code': 'mostly_cloudy'},
    '2000': {'text': 'Fog', 'code': 'fog'},
    '2100': {'text': 'Light Fog', 'code': 'fog_light'},
    '3000': {'text': 'Light Wind', 'code': 'light_wind'},
    '3001': {'text': 'Wind', 'code': 'wind'},
    '3002': {'text': 'Strong Wind', 'code': 'strong_wind'},
    '4000': {'text': 'Drizzle', 'code': 'drizzle'},
    '4001': {'text': 'Rain', 'code': 'rain'},
    '4200': {'text': 'Light Rain', 'code': 'rain_light'},
    '4201': {'text': 'Heavy Rain', 'code': 'rain_heavy'},
    '5000': {'text': 'Snow', 'code': 'snow'},
    '5001': {'text': 'Flurries', 'code': 'flurries'},
    '5100': {'text': 'Light Snow', 'code': 'snow_light'},
    '5101': {'text': 'Heavy Snow', 'code': 'snow_heavy'},
    '6000': {'text': 'Freezing Drizzle', 'code': 'freezing_drizzle'},
    '6001': {'text': 'Freezing Rain', 'code': 'freezing_rain'},
    '6200': {'text': 'Freezing Rain Light', 'code': 'freezing_rain_light'},
    '6201': {'text': 'Freezing Rain Heavy', 'code': 'freezing_rain_heavy'},
    '7000': {'text': 'Ice Pellets', 'code': 'ice_pellets'},
    '7101': {'text': 'Ice Pellets Heavy', 'code': 'ice_pellets_heavy'},
    '7102': {'text': 'Ice Pellets Light', 'code': 'ice_pellets_light'},
    '8000': {'text': 'Thunderstorm', 'code': 'thunderstorm'}
}

const WEATHER_CODE_DAY_NIGHT_FIELDS = [1000, 1100, 1101, 1102];

app.use(cors());
app.use(express.urlencoded({extended: true,}));
app.use(express.json({limit: '50mb',}));

function requests(options) {
    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            if (!error && response.statusCode === 200) {
                resolve(body)
            } else {
                reject(body)
            }
        });
    });
}

function getWeatherIcon(data) {
    for (let d of data) {
        d.weather = WEATHER_CODE_DICT[d.values.weatherCode].code
        d.weather_text = WEATHER_CODE_DICT[d.values.weatherCode].text;
    }
}

function getWeather(location, timeStep = '1d', fields) {
    let url = "https://api.tomorrow.io/v4/timelines";
    let querystring = {
        "units": "imperial", "timesteps": timeStep,
        "timezone": "America/Los_Angeles", "apikey": API_KEYS.weather,
        "location": location, "fields": fields.join(",")
    }
    let option = {
        url,
        method: "GET",
        headers: {"Accept": "application/json"},
        json: true,
        qs: querystring
    }
    return requests(option)
}

function getPrediction(input) {
    let url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${input}&types=(cities)&components=country:us&key=AIzaSyD4uhd9rjONfLoBlXjYBg_pVv3ywP2XFg8`;
    let option = {
        url,
        method: "GET",
        json: true,
        headers: {"Accept": "application/json"},
    }
    return requests(option)
}

function getGeocode(street, city, state) {
    let address = `${street} ${city} ${state}`.replace(/\s+/g, "+");
    let url = `https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${API_KEYS.geoCode}`
    let option = {
        url,
        method: "GET",
        json: true,
        headers: {"Accept": "application/json"},
    }
    return requests(option)
}

app.get('/', (req, res) => {
    res.json({"status": "worked"})
});

app.get('/weather', function (req, res) {
    //test:http://localhost:5000/weather?location=34.0223519,-118.285117
    let {location, timeStep, fields} = req.query;
    fields = fields ? fields.split(',') : WEATHER_FIELDS
    getWeather(location, timeStep, fields).then(resp => {
        const timeline = resp.data.timelines[0];
        if (fields && fields.indexOf('weatherCode') !== -1)
            getWeatherIcon(timeline.intervals)
        const startTime = moment(timeline.startTime).format("dddd, DD MMM YYYY");
        timeline.intervals.forEach(item => {
            item.timestamp = moment(item.startTime).unix() * 1000
            item.startTime = moment(item.startTime).format("dddd, DD MMM YYYY");
        })
        const results = {
            data: timeline.intervals,
            startTime: startTime,
            endTime: timeline.endTime
        }
        return res.json(results)
    }).catch(error => {
        return res.json(error)
    })
})
app.get('/predict', function (req, res) {
    let {input} = req.query;
    if (input)
        getPrediction(input).then(result => {
            let results = [];
            result.predictions.forEach(item => {
                results.push({
                    description: item.description,
                    state: STATE[item.terms[1].value],
                    city: item.terms[0].value,
                    street: item.terms[0].value
                })
            })
            res.json(results)
        }).catch(error => {
            res.json(error)
        })
    else
        res.json({'error': 'input is null'})
})
app.get('/geocode', function (req, res) {
    //test: http://localhost:8080/geocode?city=Los%20Alamos&state=New%20Mexico&street=2
    let {street, city, state} = req.query;
    getGeocode(street, city, state).then(data => {
        let location = data["results"][0]["geometry"]["location"];
        let formatAddress = data["results"][0]["formatted_address"];
        return res.json({lat: location['lat'], lng: location['lng'], formatAddress})
    }).catch(error => {
        return res.json(error)
    })
})

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Backend is now listening on port ${PORT}!`);
    console.log(`For API docs, navigate to http://localhost:${PORT}`);
});
