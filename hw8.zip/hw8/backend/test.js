import request from "request";

const url = "https://maps.googleapis.com/maps/api/geocode/json?address=University+of+Southern+California+CA&key=AIzaSyBq_oD-Y35Xtj-1rpjGlOlsa_E1oA7PQmM";

function requests(options) {
    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            if (!error && response.statusCode === 200) {
                resolve(body)
            } else {
                reject(body)
            }
        });
    });
}

function get_weather() {
    let url = "https://api.tomorrow.io/v4/timelines";
    let querystring = {
        "units": "imperial", "timesteps": "1h",
        "timezone": "America/Los_Angeles", "apikey": "4KRrfC5evWuTbSrIKAIt9esP0tBfDdlQ",
        "location": '34.0223519,-118.285117', "fields": "temperature"
    }
    let headers = {"Accept": "application/json"};
    let options = {
        url,
        method: "GET",
        json: true,
        headers,
        qs: querystring
    }
    return requests(options)
}

function getPrediction(input) {
    let url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=L&key=AIzaSyAmq6zgFx8wkyhYjc1nbUZ6qbIO7hMf4UY`
    let option = {
        url,
        method: "GET",
        headers: {"Accept": "application/json"},
        json: true,
    }
    return requests(option)
}

get_weather()