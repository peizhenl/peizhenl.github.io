# weather-nuxt

## Dev Setup Steps

```bash
# install dependencies
$ npm install

# serve with hot reload at localhost:3000
$ npm run dev
```

## Production Setup Steps

```bash
# build for production and launch server
$ npm install --production
$ npm run build
$ npm run start
```

## Google App Engine Setup Steps
follow [Production Setup Steps](#Production-Setup-Steps) first

then:
```bash
gcloud app deploy app.yaml --project weather-web
```
