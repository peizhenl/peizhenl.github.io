<template>
  <b-container>
    <b-row cols='12'>
      <b-col offset='3' cols='6'>
        <SearchComp class='mt-5' :trigger='trigger' :reset='reset' />
      </b-col>
    </b-row>
    <b-row v-if='once && visible && !visDaily' cols='12' class='mt-5'>
      <b-col offset='3' cols='6'>
        <DetailsComp :data='detail'></DetailsComp>
      </b-col>
    </b-row>
    <b-row v-if='once && !visible' cols='12' class='mt-1'>
      <b-col offset='3' cols='6' style='text-align: center'>
        <div class='text-main-darker m-2' style='font-size: 14pt;text-align: center;background-color: white'>No records
          have been found.
        </div>
      </b-col>
    </b-row>
    <b-row v-if='once && visible && !visDaily' cols='12' class='mt-5'>
      <b-col offset='1' cols='10'>
        <TableComp :list='list' :handle-details='onDaily'></TableComp>
      </b-col>
    </b-row>
    <b-row v-if='once && visible && visDaily' cols='12' class='mt-5'>
      <b-col offset='3' cols='6'>
        <DailyComp :data='daily'></DailyComp>
      </b-col>
    </b-row>
    <b-row v-if='once && visible && visDaily' cols='12' class='mt-5'>
      <b-col offset='1' cols='10'>
        <ChartsComp :range='list' :hours='hours'></ChartsComp>
      </b-col>
    </b-row>
  </b-container>
</template>

<script>

export default {
  data() {
    return {
      once: false,
      visible: false,
      visDaily: false,
      detail: {},
      list: [],
      hours: [],
      select: '',
      daily: {}
    }
  },
  methods: {
    trigger(detect, street, city, state) {
      const req = {
        detect,
        street,
        city,
        state
      }
      this.$api.weather(req)
        .then(resp => {
          if (resp.status !== 200) {
            this.onError()
            return
          }
          const d = resp.data
          const res = d.current
          res.location = d.location
          this.detail = res
          this.list = d['15day']
          this.once = true
          this.visible = true
          this.visDaily = false
        })
        .catch(err => {
          console.error(err)
          this.onError()
        })
        .finally(() => {
          this.$api.hours(req)
            .then(res => {
              if (res.status === 200) {
                this.hours = res.data
              }
            })
            .catch(err => {
              console.error(err)
            })
        })
    },
    reset() {
      this.once = false
      this.visible = false
      this.visDaily = false
    },
    onDaily(data) {
      this.once = true
      this.visible = true
      this.visDaily = true
      this.daily = data
    },
    onError() {
      this.once = true
      this.visible = false
      this.visDaily = false
    }
  }
}
</script>
