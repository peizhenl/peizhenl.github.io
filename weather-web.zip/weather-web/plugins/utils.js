import Vue from 'vue'
import testData from '@/data/test'
import constant from '@/data/constant'
import iconUtils from '@/plugins/iconUtils'
Vue.prototype.$testData = testData
Vue.prototype.$con = constant
Vue.prototype.$icon = iconUtils

