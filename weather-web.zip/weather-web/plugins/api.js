const baseUrl = 'https://myhw6-94534.uw.r.appspot.com/'
export default ({ $axios }, inject) => {
  const api = {
    weather(data) {
      return get(`/weather`, data)
    },
    hours(data){
      return get(`/hours`, data)
    }
  }
  const get = (url, data) => {
    return $axios.get(baseUrl + url, { params: data })
  }
  inject('api', api)
}
