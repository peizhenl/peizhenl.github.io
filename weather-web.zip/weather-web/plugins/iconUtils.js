import icons from '~/data/weather'

export function getIcon(code) {
  code = code + ''
  let obj = icons[code]
  if (obj == null) {
    console.warn('weather code not found',code)
    obj = icons['1000']
  }
  return require(`@/static/weather/${obj.icon}`)
}

export function getName(code) {
  code = code + ''
  let obj = icons[code]
  if (obj == null) {
    console.warn('weather code not found',code)
    obj = icons['1000']
  }
  return obj.name
}

export default { getIcon, getName }
