// 全局加载组件
import Vue from 'vue'
import moment from 'moment'
Vue.prototype.$moment = moment
