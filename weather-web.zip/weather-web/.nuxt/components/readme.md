# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<ChartsComp>` | `<charts-comp>` (components/ChartsComp.vue)
- `<CompTitle>` | `<comp-title>` (components/CompTitle.vue)
- `<DailyComp>` | `<daily-comp>` (components/DailyComp.vue)
- `<DetailsComp>` | `<details-comp>` (components/DetailsComp.vue)
- `<HoursChart>` | `<hours-chart>` (components/HoursChart.vue)
- `<RangeCharts>` | `<range-charts>` (components/RangeCharts.vue)
- `<SearchComp>` | `<search-comp>` (components/SearchComp.vue)
- `<TableComp>` | `<table-comp>` (components/TableComp.vue)
