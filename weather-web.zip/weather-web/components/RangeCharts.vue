<template>
  <div>
    <div id='chart'></div>
  </div>
</template>

<script>
import Highcharts from 'highcharts'
import highchartsMore from 'highcharts/highcharts-more'

export default {
  name: 'RangeCharts',
  props: {
    data: Array
  },
  data() {
    return {
      options: {
        chart: {
          type: 'arearange',
          zoomType: 'x',
          scrollablePlotArea: {
            minWidth: 600,
            scrollPositionX: 1
          }
        },
        plotOptions: {
          series: {
            fillColor: {
              linearGradient: [0, 0, 0, 400],
              stops: [
                [0, '#F5AB3B'],
                [1, Highcharts.color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
              ]
            }
          }
        },
        title: {
          text: 'Temperature Ranges (Min, Max)'
        },
        xAxis: {
          type: 'datetime',
          accessibility: {
            rangeDescription: 'Range: Jan 1st 2017 to Dec 31 2017.'
          },
          crosshair: {
            width: 1,
            color: 'grey',
            dashStyle: 'shortdot'
          }
        },
        yAxis: {
          title: {
            text: null
          }
        },
        legend: {
          enabled: false
        },
        series: [{
          name: 'Temperatures',
          data: []
        }],
        tooltip: {
          valueSuffix: '℉'
        }
      }
    }
  },
  mounted() {
    const opt = this.options
    opt.series = [{ name: 'Temperature', data: this.chartData() }]
    highchartsMore(Highcharts)
    Highcharts.chart('chart', opt)
  },
  methods: {
    chartData() {
      const arr = []
      for (let i = 0; i < this.data.length; i++) {
        const item = this.data[i]
        const d = []
        d[0] = this.$moment(item.startTime).unix() * 1000
        d[1] = item.values.temperatureMin
        d[2] = item.values.temperatureMax
        arr[i] = d
      }
      return arr
    }
  }
}
</script>

<style scoped>

</style>
