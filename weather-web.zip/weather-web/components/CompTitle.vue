<template>
  <div>
    <h1 style='text-align: center;'>{{ title }}</h1>
    <hr style='border-color: white'/>
  </div>
</template>

<script>
export default {
  name: 'CompTitle',
  props: {
    title: String
  }
}
</script>

<style scoped>

</style>
