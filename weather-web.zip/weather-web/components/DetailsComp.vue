<template>
  <b-form class='m-2 bg-white card'>
    <b-container>
      <b-row cols='12' class='pt-3'>
        <b-col cols='12'>
          <label class='text-grey' style='font-size: 18pt'>{{ data.location }}</label>
        </b-col>
      </b-row>
      <b-row cols='12'>
        <b-col cols='6'>
          <b-img width='100' height='100' :src='getCurrentIcon()'></b-img>
        </b-col>
        <b-col cols='6'>
          <label class='text-grey' style='font-size: 52pt'>{{ data.values.temperature }}&#176;</label>
        </b-col>
      </b-row>
      <b-row cols='12' class='ml-1 mb-3'>
        <b-col cols='12'>
          <div class='text-grey' style='font-size: 16pt'>{{ getCurrentName() }}</div>
        </b-col>
      </b-row>
      <b-row cols='12' class='pt-2 pb-3'>
        <b-col v-for='i in details' :key='i.id' cols='2' class='pl-1 pr-1' style='text-align: center'>
          <div class='text-sub'>{{ i.text }}</div>
          <b-img class='mt-2 mb-2' width='25' height='25' :src='i.icon'></b-img>
          <div class='text-sub'>{{ i.value }} {{ i.unit }}</div>
        </b-col>
      </b-row>
    </b-container>
  </b-form>
</template>

<script>
import { getIcon, getName } from '~/plugins/iconUtils'

export default {
  name: 'DetailComp',
  props: {
    data: Object
  },
  data() {
    return {
      details: []
    }
  },
  mounted() {
    const arr = []
    const keys = ['humidity', 'pressure', 'windSpeed', 'visibility', 'cloudCover', 'uvIndex']
    for (const i in keys) {
      const k = keys[i]
      let target = k
      if (k === 'pressure') {
        target = 'pressureSeaLevel'
      }
      arr[i] = {
        id: k,
        text: this.$con.getText(k),
        icon: this.$con.getIcon(k),
        unit: this.$con.getUnit(k),
        value: this.data.values[target]
      }
      this.details = arr
    }
  },
  methods: {
    getCurrentName() {
      return getName(this.data.values.weatherCode)
    },
    getCurrentIcon() {
      return getIcon(this.data.values.weatherCode)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
