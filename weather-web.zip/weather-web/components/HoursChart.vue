<template>
  <div>
    <div id='hoursChart'></div>
  </div>
</template>

<script>
import Highcharts from 'highcharts'
import highchartsMore from 'highcharts/highcharts-more'

export default {
  name: 'HoursCharts',
  props: {
    data: Array
  },
  data() {
    return {
      options: {
        chart: {
          marginBottom: 70,
          marginRight: 40,
          marginTop: 50,
          plotBorderWidth: 1,
          height: 310,
          alignTicks: false,
          scrollablePlotArea: {
            minWidth: 720
          }
        },
        title: {
          text: 'Hourly Weather (For Next 5 Days)',
          align: 'center',
          style: {
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis'
          }
        },
        xAxis: [{ // Bottom X axis
          type: 'datetime',
          tickInterval: 2 * 36e5, // two hours
          minorTickInterval: 36e5, // one hour
          tickLength: 0,
          gridLineWidth: 1,
          gridLineColor: 'rgba(128, 128, 128, 0.1)',
          startOnTick: false,
          endOnTick: false,
          minPadding: 0,
          maxPadding: 0,
          offset: 30,
          showLastLabel: true,
          labels: {
            format: '{value:%H}'
          },
          crosshair: true
        }, { // Top X axis
          linkedTo: 0,
          type: 'datetime',
          tickInterval: 24 * 3600 * 1000,
          labels: {
            format: '{value:<span style="font-size: 12px; font-weight: bold">%a</span> %b %e}',
            align: 'left',
            x: 3,
            y: -5
          },
          opposite: true,
          tickLength: 20,
          gridLineWidth: 1
        }],

        yAxis: [{ // temperature axis
          title: {
            text: null
          },
          labels: {
            format: '{value}℉',
            style: {
              fontSize: '10px'
            },
            x: -3
          },
          plotLines: [{ // zero plane
            value: 0,
            color: '#BBBBBB',
            width: 1,
            zIndex: 2
          }],
          maxPadding: 0.3,
          minRange: 8,
          tickInterval: 1,
          gridLineColor: 'rgba(128, 128, 128, 0.1)'

        }, { // humility axis
          title: {
            text: '%'
          },
          labels: {
            enabled: false
          },
          gridLineWidth: 0,
          tickLength: 0,
          minRange: 10,
          min: 0
        }, { // Air pressure
          allowDecimals: false,
          title: { // Title on top of axis
            text: 'inHG',
            offset: 0,
            align: 'high',
            rotation: 0,
            style: {
              fontSize: '10px',
              color: Highcharts.getOptions().colors[2]
            },
            textAlign: 'left',
            x: 3
          },
          labels: {
            style: {
              fontSize: '8px',
              color: Highcharts.getOptions().colors[2]
            },
            y: 2,
            x: 3
          },
          gridLineWidth: 0,
          opposite: true,
          showLastLabel: false
        }],

        legend: {
          enabled: false
        },

        plotOptions: {
          series: {
            pointPlacement: 'between'
          }
        },
        series: [{
          name: 'Temperature',
          data: [],
          type: 'spline',
          marker: {
            enabled: false,
            states: {
              hover: {
                enabled: true
              }
            }
          },
          tooltip: {
            pointFormat: '<span style="color:{point.color}">\u25CF</span> ' +
              '{series.name}: <b>{point.y}℉</b><br/>'
          },
          zIndex: 1,
          color: '#FF3333',
          negativeColor: '#48AFE8'
        }, {
          name: 'Humility',
          data: this.humility,
          type: 'column',
          color: '#68CFE8',
          yAxis: 1,
          groupPadding: 0,
          pointPadding: 0,
          grouping: false,
          dataLabels: {
            filter: {
              operator: '>',
              property: 'y',
              value: 0
            },
            style: {
              fontSize: '8px',
              color: 'gray'
            }
          },
          tooltip: {
            valueSuffix: '%'
          }
        }, {
          name: 'Air pressure',
          color: Highcharts.getOptions().colors[2],
          data: this.pressures,
          marker: {
            enabled: false
          },
          shadow: false,
          tooltip: {
            valueSuffix: ' inHg'
          },
          dashStyle: 'shortdot',
          yAxis: 2
        }, {
          name: 'Wind',
          id: 'windbarbs',
          color: Highcharts.getOptions().colors[1],
          lineWidth: 1.5,
          data: this.winds,
          vectorLength: 18,
          yOffset: -15,
          tooltip: {
            valueSuffix: ' mph'
          }
        }]
      }
    }
  },
  mounted() {
    this.chartData()
    highchartsMore(Highcharts)
    Highcharts.chart('hoursChart', this.options)
  },
  methods: {
    chartData() {
      const temp = []
      const pressure = []
      const humility = []
      const wind = []
      for (let i = 0; i < this.data.length; i++) {
        const item = this.data[i]
        const datetime = this.$moment(item.startTime).unix()*1000
        temp[i] = [datetime,item.values.temperature]
        pressure[i] = [datetime,item.values.pressureSeaLevel]
        humility[i] = [datetime,item.values.humidity]
        wind[i] = [datetime,item.values.windSpeed]
      }
      this.$set(this.options.series[0],'data',temp)
      this.$set(this.options.series[1],'data',humility)
      this.$set(this.options.series[2],'data',pressure)
      this.$set(this.options.series[3],'data',wind)
    }
  }
}
</script>

<style scoped>

</style>
