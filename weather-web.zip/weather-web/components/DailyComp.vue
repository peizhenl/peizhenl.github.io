<template>
  <div class='card'>
    <CompTitle title='Daily Weather Details' />
    <b-container class='bg-daily'>
      <b-row cols='12'>
        <b-col cols='7'>
          <div class='m-3 text-main-darker' style='font-size: 20pt'>
            {{ date }}
          </div>
          <div class='m-3 text-main-darker' style='font-size: 17pt'>
            {{ getWeatherName(data.weatherCode) }}
          </div>
          <div class='m-3 text-main-darker' style='font-size: 25pt'>
            {{ data.temperatureMax }}&#8457;/{{ data.temperatureMin }}&#8457;
          </div>
        </b-col>
        <b-col cols='5'>
          <b-img width='150' height='150' :src='getWeatherIcon(data.weatherCode)' class='m-4'></b-img>
        </b-col>
      </b-row>
      <b-row v-for='item in details' :key='item.id' cols='12' style='font-size: 12pt'>
        <b-col offset='3' cols='4' class='pr-0' style='text-align: right;color: white'>
          <label>{{ item.name }}:</label>
        </b-col>
        <b-col cols='3' class='pl-1' style='text-align: left;color: white;font-weight: bold'>
          <label>{{ item.value }}{{ item.unit }}</label>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>

<script>
import { getIcon, getName } from '~/plugins/iconUtils'
export default {
  name: 'DailyComp',
  props: {
    data: Object
  },
  data() {
    return {
      date: '',
      details: []
    }
  },
  mounted() {
    console.log(this.data)
    this.date = this.$moment(this.data.startTime).format('dddd,DD MMM YYYY')
    this.details = [{
      id: 1,
      name: 'Precipitation',
      value: this.getType(this.data.precipitationType),
      unit: ''
    }, {
      id: 2,
      name: 'Chance of Rain',
      value: this.data.precipitationProbability,
      unit: '%'
    }, {
      id: 3,
      name: 'Wind Speed',
      value: this.data.windSpeed,
      unit: ' mph'
    }, {
      id: 4,
      name: 'Humidity',
      value: this.data.humidity,
      unit: '%'
    }, {
      id: 5,
      name: 'Visibility',
      value: this.data.visibility,
      unit: ' mi'
    }, {
      id: 6,
      name: 'Sunrise/Sunset',
      value: this.getSRS(this.data.sunriseTime, this.data.sunsetTime),
      unit: ''
    }]
  },
  methods: {
    getType(type) {
      const arr = ['N/A', 'Rain', 'Snow', 'Freezing Rain', 'Ice Pellets']
      if (type <= 0 || type > 4) {
        return arr[0]
      }
      return arr[type]
    },
    getSRS(sunrise, sunset) {
      return `${this.$moment(sunrise).format('hA')}/${this.$moment(sunset).format('hA')}`
    },
    getWeatherIcon(code) {
      return getIcon(code)
    },
    getWeatherName(code) {
      return getName(code)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.bg-daily {
  background-image: linear-gradient(#FFFFFF, #3A507A);
}
</style>
