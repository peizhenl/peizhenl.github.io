<template>
  <b-table outlined :fields='fields' :items='items' tbody-tr-class='t-tr' thead-class='bg-main'>
    <template #cell(date)='data'>
      <b-link href='#' @click='handle(data.item.vals)'>{{ data.value }}</b-link>
    </template>
    <template #cell(weather)='data'>
      <b-img width='60' height='60' :src='getWeatherIcon(data.item.weather)'></b-img>
      {{ getWeatherName(data.item.weather) }}
    </template>
  </b-table>
</template>
<script>
import { getIcon, getName } from '~/plugins/iconUtils'

export default {
  name: 'TableComp',
  props: {
    list: Array,
    handleDetails: Function
  },
  data() {
    return {
      fields: [{
        key: 'date',
        label: 'Date'
      }, {
        key: 'weather',
        label: 'Status'
      }, {
        key: 'tempHigh',
        label: 'Temp High'
      }, {
        key: 'tempLow',
        label: 'Temp Low'
      }, {
        key: 'windSpeed',
        label: 'Wind Speed'
      }],
      items: []
    }
  },
  mounted() {
    const arr = []
    let len = 0
    for (let i = 0; i < this.list.length; i++) {
      const d = this.list[i]
      const obj = {}
      obj.vals = d.values
      obj.date = this.$moment(d.startTime).format('dddd,DD MMM YYYY')
      obj.vals.date = obj.date
      obj.weather = d.values.weatherCode
      obj.tempHigh = d.values.temperatureMax
      obj.tempLow = d.values.temperatureMin
      obj.windSpeed = d.values.windSpeed
      arr[len++] = obj
    }
    this.items = arr
  },
  methods: {
    handle(data) {
      this.handleDetails(data)
    },
    getWeatherIcon(code) {
      return getIcon(code)
    },
    getWeatherName(code) {
      return getName(code)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
