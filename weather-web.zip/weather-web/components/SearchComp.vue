<template>
  <b-form class='m-2 bg-white' @submit.prevent='onSubmit' @reset='onReset'>
    <b-container>
      <b-row class='p-2' cols='12' :style='{backgroundImage: banner}'>
        <b-col cols='12'>
          <b-card-title class='mt-3 mb-3' style='font-size: 25pt;'>Weather Search</b-card-title>
        </b-col>
        <b-col cols='12'>
          <b-card-sub-title class='mb-1' style='font-size: 13pt'>Fill out the form to get weather info !
          </b-card-sub-title>
        </b-col>
      </b-row>
    </b-container>
    <div class='ml-4 mr-4 mt-2 mb-2'>
      <b-form-group
        id='input-street-gp'
      >
        <slot name='label'>
          <label class='text-main'>Street</label>&nbsp;<label style='color: red'>*</label>
        </slot>
        <b-form-input
          id='input-street'
          v-model='form.street'
          type='text'
          :required='req'
          :disabled='!req'
        ></b-form-input>
      </b-form-group>
      <b-row cols='12'>
        <b-col cols='6'>
          <b-form-group id='input-city-gp' label-for='input-city'>
            <slot name='label'>
              <label class='text-main'>City</label>&nbsp;<label style='color: red'>*</label>
            </slot>
            <b-form-input
              id='input-city'
              v-model='form.city'
              :required='req'
              :disabled='!req'
            ></b-form-input>
          </b-form-group>
        </b-col>
        <b-col cols='6'>
          <b-form-group id='input-state-gp' label-for='input-state'>
            <slot name='label'>
              <label class='text-main'>State</label>&nbsp;<label class='text-danger'>*</label>
            </slot>
            <b-form-select
              id='input-state'
              v-model='form.state'
              :required='req'
              :disabled='!req'
            >
              <b-form-select-option v-for="(item,i) in states" :key='i' :value="item.value" :disabled="item.value===null">{{item.text}}</b-form-select-option>
            </b-form-select>
          </b-form-group>
        </b-col>
      </b-row>
      <hr class='bg-main' />
      <b-form-group id='input-auto-detect-gp'>
        <b-form-checkbox-group id='input-auto-detect' v-model='form.detect' @change='detectChange'>
          <label class='text-main'>Want us to auto-detect your location? Check here</label>
          <b-form-checkbox value='detect' :inline='true'>&nbsp;</b-form-checkbox>
        </b-form-checkbox-group>
      </b-form-group>
      <div class='pb-2'>
        <b-button squared class='btn-primary' active-class='btn-primary-active' type='submit'>SUBMIT</b-button>
        <b-button squared class='btn-warning' active-class='btn-warning-active' type='reset'>CLEAR</b-button>
      </div>
    </div>
  </b-form>
</template>

<script>

export default {
  name: 'SearchComp',
  props: {
    trigger: Function,
    reset: Function
  },
  data() {
    return {
      req: true,
      banner: 'url(' + require('@/static/banner.jpg') + ')',
      form: {
        street: '',
        city: '',
        state: null,
        detect: []
      },
      states: []
    }
  },
  mounted() {
    const arr = [{
      value:null,
      text:''
    }]
    this.states = arr.concat(this.$con.states.getArray().map(e => {
      return {
        value: e.key,
        text: e.value
      }
    }))
    console.log(this.states)
  },
  methods: {
    onSubmit() {
      const detect = this.form.detect.length > 0
      if (detect) {
        this.form = {
          detect: this.form.detect,
          street: '',
          city: '',
          state: null
        }
      }
      this.trigger(detect, this.form.street, this.form.city, this.form.state)
      return false
    },
    onReset() {
      this.form = {
        detect: [],
        street: '',
        city: '',
        state: null
      }
      this.detectChange([])
      this.reset()
    },
    detectChange(e) {
      this.req = !(e.length>0)
      if(!this.req) {
        this.form = {
          detect: e,
          street: '',
          city: '',
          state: null
        }
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
