<template>
  <div>
    <CompTitle title='Weather Charts' />
    <div class='text-center' >
      <b-img v-b-toggle.charts :src='icon' width='80' height='80' @click="open = !open"></b-img>
    </div>
    <b-collapse id='charts' class='mt-2'>
      <RangeCharts :data='range'></RangeCharts>
    </b-collapse>
    <b-collapse id='charts' class='mt-2'>
      <HoursChart :data='hours'></HoursChart>
    </b-collapse>
  </div>
</template>

<script>
export default {
  name: 'ChartsComp',
  props: {
    range: Array,
    hours: Array
  },
  data() {
    return {
      open: false
    }
  },
  computed: {
    icon() {
      if (this.open) {
        return require('@/static/point-down-512.png')
      } else {
        return require('@/static/point-up-512.png')
      }
    }
  },
  methods: {
    toggle() {
      this.open = !this.open
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
