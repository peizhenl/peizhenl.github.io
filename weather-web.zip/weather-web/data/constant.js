import states from '@/data/states'

const data = {
  humidity: {
    id: 'humidity',
    text: 'Humidity',
    icon: require('@/static/icon/humidity.png'),
    value: 31,
    unit: '%'
  },
  pressure: {
    id: 'pressure',
    text: 'Pressure',
    icon: require('@/static/icon/pressure.png'),
    unit: 'inHg'
  },
  windSpeed: {
    id: 'windSpeed',
    text: 'Wind Speed',
    icon: require('@/static/icon/wind_speed.png'),
    unit: 'mph'
  },
  visibility: {
    id: 'visibility',
    text: 'Visibility',
    icon: require('@/static/icon/visibility.png'),
    unit: 'mi'
  },
  cloudCover: {
    id: 'cloudCover',
    text: 'Cloud Cover',
    icon: require('@/static/icon/cloud_cover.png'),
    unit: '%'
  },
  uvIndex: {
    id: 'uvIndex',
    text: 'UV Level',
    icon: require('@/static/icon/uv_level.png'),
    unit: ''
  }
}

function getText(id) {
  return getParam(id, 'text')
}

function getIcon(id) {
  return getParam(id, 'icon')
}

function getUnit(id) {
  return getParam(id, 'unit')
}

function getParam(id, key) {
  const d = data[id]
  if (d) {
    return d[key]
  }
  return ''
}

export default {
  getText,
  getUnit,
  getIcon,
  states,
}
