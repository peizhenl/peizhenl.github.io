const weather={
  "15day": [
    {
      "startTime": "2021-10-04",
      "values": {
        "humidity": 88.21,
        "precipitationProbability": 35,
        "precipitationType": 1,
        "sunriseTime": "2021-10-04T06:50:00-07:00",
        "sunsetTime": "2021-10-04T18:33:20-07:00",
        "temperatureMax": 91.22,
        "temperatureMin": 65.26,
        "visibility": 9.94,
        "weatherCode": 1001,
        "windSpeed": 9.89
      }
    },
    {
      "startTime": "2021-10-05",
      "values": {
        "humidity": 99.48,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-05T06:50:00-07:00",
        "sunsetTime": "2021-10-05T18:31:40-07:00",
        "temperatureMax": 77.56,
        "temperatureMin": 58.59,
        "visibility": 9.94,
        "weatherCode": 1000,
        "windSpeed": 15.1
      }
    },
    {
      "startTime": "2021-10-06",
      "values": {
        "humidity": 99.34,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-06T06:51:40-07:00",
        "sunsetTime": "2021-10-06T18:30:00-07:00",
        "temperatureMax": 76.48,
        "temperatureMin": 57.74,
        "visibility": 9.94,
        "weatherCode": 1001,
        "windSpeed": 13.56
      }
    },
    {
      "startTime": "2021-10-07",
      "values": {
        "humidity": 95.59,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-07T06:51:40-07:00",
        "sunsetTime": "2021-10-07T18:30:00-07:00",
        "temperatureMax": 72.68,
        "temperatureMin": 61.27,
        "visibility": 15,
        "weatherCode": 1001,
        "windSpeed": 10.25
      }
    },
    {
      "startTime": "2021-10-08",
      "values": {
        "humidity": 63.08,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-08T06:51:40-07:00",
        "sunsetTime": "2021-10-08T18:26:40-07:00",
        "temperatureMax": 73.65,
        "temperatureMin": 64.44,
        "visibility": 15,
        "weatherCode": 1001,
        "windSpeed": 11.72
      }
    },
    {
      "startTime": "2021-10-09",
      "values": {
        "humidity": 51.98,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-09T06:53:20-07:00",
        "sunsetTime": "2021-10-09T18:26:40-07:00",
        "temperatureMax": 74.68,
        "temperatureMin": 64.99,
        "visibility": 15,
        "weatherCode": 1000,
        "windSpeed": 11.16
      }
    },
    {
      "startTime": "2021-10-10",
      "values": {
        "humidity": 23.92,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-10T06:53:20-07:00",
        "sunsetTime": "2021-10-10T18:25:00-07:00",
        "temperatureMax": 84,
        "temperatureMin": 69.67,
        "visibility": 15,
        "weatherCode": 1000,
        "windSpeed": 10.78
      }
    },
    {
      "startTime": "2021-10-11",
      "values": {
        "humidity": 68.02,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-11T06:53:20-07:00",
        "sunsetTime": "2021-10-11T18:23:20-07:00",
        "temperatureMax": 80.69,
        "temperatureMin": 66.33,
        "visibility": 15,
        "weatherCode": 1001,
        "windSpeed": 8.97
      }
    },
    {
      "startTime": "2021-10-12",
      "values": {
        "humidity": 40.54,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-12T06:56:40-07:00",
        "sunsetTime": "2021-10-12T18:23:20-07:00",
        "temperatureMax": 77.4,
        "temperatureMin": 65.68,
        "visibility": 15,
        "weatherCode": 1000,
        "windSpeed": 19.64
      }
    },
    {
      "startTime": "2021-10-13",
      "values": {
        "humidity": 29.02,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-13T06:56:40-07:00",
        "sunsetTime": "2021-10-13T18:21:40-07:00",
        "temperatureMax": 79.14,
        "temperatureMin": 65.91,
        "visibility": 15,
        "weatherCode": 1000,
        "windSpeed": 12.35
      }
    },
    {
      "startTime": "2021-10-14",
      "values": {
        "humidity": 63.8,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-14T06:58:20-07:00",
        "sunsetTime": "2021-10-14T18:21:40-07:00",
        "temperatureMax": 77.27,
        "temperatureMin": 61.77,
        "visibility": 15,
        "weatherCode": 1000,
        "windSpeed": 8.37
      }
    },
    {
      "startTime": "2021-10-15",
      "values": {
        "humidity": 65.15,
        "precipitationProbability": 5,
        "precipitationType": 1,
        "sunriseTime": "2021-10-15T06:58:20-07:00",
        "sunsetTime": "2021-10-15T18:18:20-07:00",
        "temperatureMax": 69.98,
        "temperatureMin": 62.1,
        "visibility": 15,
        "weatherCode": 1101,
        "windSpeed": 13.06
      }
    },
    {
      "startTime": "2021-10-16",
      "values": {
        "humidity": 65.39,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-16T06:58:20-07:00",
        "sunsetTime": "2021-10-16T18:16:40-07:00",
        "temperatureMax": 73.58,
        "temperatureMin": 63.61,
        "visibility": 15,
        "weatherCode": 1100,
        "windSpeed": 10.78
      }
    },
    {
      "startTime": "2021-10-17",
      "values": {
        "humidity": 38.57,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-17T07:00:00-07:00",
        "sunsetTime": "2021-10-17T18:16:40-07:00",
        "temperatureMax": 80.74,
        "temperatureMin": 66.85,
        "visibility": 15,
        "weatherCode": 1001,
        "windSpeed": 9.46
      }
    },
    {
      "startTime": "2021-10-18",
      "values": {
        "humidity": 20.08,
        "precipitationProbability": 0,
        "precipitationType": 0,
        "sunriseTime": "2021-10-18T07:00:00-07:00",
        "sunsetTime": "2021-10-18T18:15:00-07:00",
        "temperatureMax": 84.87,
        "temperatureMin": 71.98,
        "visibility": 15,
        "weatherCode": 1101,
        "windSpeed": 8.34
      }
    }
  ],
  "current": {
    "startTime": "2021-10-04",
    "values": {
      "cloudCover": 100,
      "humidity": 40,
      "pressureSeaLevel": 29.89,
      "temperature": 67.78,
      "uvIndex": 0,
      "visibility": 9.94,
      "weatherCode": 1001,
      "windSpeed": 1.97
    }
  },
  "location": "Los Angeles, CA 90007, USA"
}
const hours=[
  {
    "startTime": "2021-10-04T08:00:00-07:00",
    "values": {
      "humidity": 89,
      "pressureSeaLevel": 30.09,
      "temperature": 74.08,
      "windSpeed": 2.93
    }
  },
  {
    "startTime": "2021-10-04T09:00:00-07:00",
    "values": {
      "humidity": 89.78,
      "pressureSeaLevel": 30.09,
      "temperature": 73.62,
      "windSpeed": 2.8
    }
  },
  {
    "startTime": "2021-10-04T10:00:00-07:00",
    "values": {
      "humidity": 90.56,
      "pressureSeaLevel": 30.09,
      "temperature": 73.31,
      "windSpeed": 2.8
    }
  },
  {
    "startTime": "2021-10-04T11:00:00-07:00",
    "values": {
      "humidity": 90.56,
      "pressureSeaLevel": 30.07,
      "temperature": 72.64,
      "windSpeed": 2.62
    }
  },
  {
    "startTime": "2021-10-04T12:00:00-07:00",
    "values": {
      "humidity": 89.15,
      "pressureSeaLevel": 30.06,
      "temperature": 72.01,
      "windSpeed": 2.59
    }
  },
  {
    "startTime": "2021-10-04T13:00:00-07:00",
    "values": {
      "humidity": 86.65,
      "pressureSeaLevel": 30.06,
      "temperature": 71.65,
      "windSpeed": 2.68
    }
  },
  {
    "startTime": "2021-10-04T14:00:00-07:00",
    "values": {
      "humidity": 84.35,
      "pressureSeaLevel": 30.07,
      "temperature": 71.11,
      "windSpeed": 2.59
    }
  },
  {
    "startTime": "2021-10-04T15:00:00-07:00",
    "values": {
      "humidity": 86.4,
      "pressureSeaLevel": 30.08,
      "temperature": 69.89,
      "windSpeed": 2.57
    }
  },
  {
    "startTime": "2021-10-04T16:00:00-07:00",
    "values": {
      "humidity": 82.81,
      "pressureSeaLevel": 30.1,
      "temperature": 71.58,
      "windSpeed": 1.95
    }
  },
  {
    "startTime": "2021-10-04T17:00:00-07:00",
    "values": {
      "humidity": 74.8,
      "pressureSeaLevel": 30.11,
      "temperature": 74.84,
      "windSpeed": 4.05
    }
  },
  {
    "startTime": "2021-10-04T18:00:00-07:00",
    "values": {
      "humidity": 66.78,
      "pressureSeaLevel": 30.12,
      "temperature": 78.1,
      "windSpeed": 6.15
    }
  },
  {
    "startTime": "2021-10-04T19:00:00-07:00",
    "values": {
      "humidity": 58.77,
      "pressureSeaLevel": 30.12,
      "temperature": 81.36,
      "windSpeed": 8.23
    }
  },
  {
    "startTime": "2021-10-04T20:00:00-07:00",
    "values": {
      "humidity": 55.01,
      "pressureSeaLevel": 30.11,
      "temperature": 83.17,
      "windSpeed": 8.9
    }
  },
  {
    "startTime": "2021-10-04T21:00:00-07:00",
    "values": {
      "humidity": 54.02,
      "pressureSeaLevel": 30.08,
      "temperature": 84.45,
      "windSpeed": 9.6
    }
  },
  {
    "startTime": "2021-10-04T22:00:00-07:00",
    "values": {
      "humidity": 53.7,
      "pressureSeaLevel": 30.06,
      "temperature": 85.06,
      "windSpeed": 9.78
    }
  },
  {
    "startTime": "2021-10-04T23:00:00-07:00",
    "values": {
      "humidity": 53.63,
      "pressureSeaLevel": 30.03,
      "temperature": 85.21,
      "windSpeed": 8.93
    }
  },
  {
    "startTime": "2021-10-05T00:00:00-07:00",
    "values": {
      "humidity": 55,
      "pressureSeaLevel": 30.02,
      "temperature": 84.63,
      "windSpeed": 8.48
    }
  },
  {
    "startTime": "2021-10-05T01:00:00-07:00",
    "values": {
      "humidity": 60.27,
      "pressureSeaLevel": 30.02,
      "temperature": 83.1,
      "windSpeed": 8.46
    }
  },
  {
    "startTime": "2021-10-05T02:00:00-07:00",
    "values": {
      "humidity": 69.93,
      "pressureSeaLevel": 30.03,
      "temperature": 80.42,
      "windSpeed": 7.78
    }
  },
  {
    "startTime": "2021-10-05T03:00:00-07:00",
    "values": {
      "humidity": 80.7,
      "pressureSeaLevel": 30.04,
      "temperature": 77.56,
      "windSpeed": 8.17
    }
  },
  {
    "startTime": "2021-10-05T04:00:00-07:00",
    "values": {
      "humidity": 87.59,
      "pressureSeaLevel": 30.06,
      "temperature": 76.23,
      "windSpeed": 7
    }
  },
  {
    "startTime": "2021-10-05T05:00:00-07:00",
    "values": {
      "humidity": 90.47,
      "pressureSeaLevel": 30.07,
      "temperature": 75.61,
      "windSpeed": 6.49
    }
  },
  {
    "startTime": "2021-10-05T06:00:00-07:00",
    "values": {
      "humidity": 91.3,
      "pressureSeaLevel": 30.08,
      "temperature": 75.43,
      "windSpeed": 5.95
    }
  },
  {
    "startTime": "2021-10-05T07:00:00-07:00",
    "values": {
      "humidity": 92.44,
      "pressureSeaLevel": 30.08,
      "temperature": 75.07,
      "windSpeed": 5.32
    }
  },
  {
    "startTime": "2021-10-05T08:00:00-07:00",
    "values": {
      "humidity": 92.85,
      "pressureSeaLevel": 30.07,
      "temperature": 74.93,
      "windSpeed": 5.68
    }
  },
  {
    "startTime": "2021-10-05T09:00:00-07:00",
    "values": {
      "humidity": 90.96,
      "pressureSeaLevel": 30.07,
      "temperature": 75.27,
      "windSpeed": 5.44
    }
  },
  {
    "startTime": "2021-10-05T10:00:00-07:00",
    "values": {
      "humidity": 91.42,
      "pressureSeaLevel": 30.06,
      "temperature": 75.2,
      "windSpeed": 5.5
    }
  },
  {
    "startTime": "2021-10-05T11:00:00-07:00",
    "values": {
      "humidity": 91.86,
      "pressureSeaLevel": 30.04,
      "temperature": 75.15,
      "windSpeed": 5.79
    }
  },
  {
    "startTime": "2021-10-05T12:00:00-07:00",
    "values": {
      "humidity": 91.64,
      "pressureSeaLevel": 30.03,
      "temperature": 74.84,
      "windSpeed": 5.84
    }
  },
  {
    "startTime": "2021-10-05T13:00:00-07:00",
    "values": {
      "humidity": 91.32,
      "pressureSeaLevel": 30.02,
      "temperature": 74.62,
      "windSpeed": 5.44
    }
  },
  {
    "startTime": "2021-10-05T14:00:00-07:00",
    "values": {
      "humidity": 92.63,
      "pressureSeaLevel": 30.03,
      "temperature": 74.25,
      "windSpeed": 5.79
    }
  },
  {
    "startTime": "2021-10-05T15:00:00-07:00",
    "values": {
      "humidity": 94.35,
      "pressureSeaLevel": 30.04,
      "temperature": 73.96,
      "windSpeed": 6.08
    }
  },
  {
    "startTime": "2021-10-05T16:00:00-07:00",
    "values": {
      "humidity": 90.44,
      "pressureSeaLevel": 30.05,
      "temperature": 75.94,
      "windSpeed": 6.31
    }
  },
  {
    "startTime": "2021-10-05T17:00:00-07:00",
    "values": {
      "humidity": 81.48,
      "pressureSeaLevel": 30.06,
      "temperature": 78.91,
      "windSpeed": 9.93
    }
  },
  {
    "startTime": "2021-10-05T18:00:00-07:00",
    "values": {
      "humidity": 72.2,
      "pressureSeaLevel": 30.06,
      "temperature": 81.16,
      "windSpeed": 9.89
    }
  },
  {
    "startTime": "2021-10-05T19:00:00-07:00",
    "values": {
      "humidity": 64.48,
      "pressureSeaLevel": 30.06,
      "temperature": 82.76,
      "windSpeed": 10.11
    }
  },
  {
    "startTime": "2021-10-05T20:00:00-07:00",
    "values": {
      "humidity": 59.33,
      "pressureSeaLevel": 30.04,
      "temperature": 83.71,
      "windSpeed": 9.78
    }
  },
  {
    "startTime": "2021-10-05T21:00:00-07:00",
    "values": {
      "humidity": 55.54,
      "pressureSeaLevel": 30.01,
      "temperature": 84.34,
      "windSpeed": 9.71
    }
  },
  {
    "startTime": "2021-10-05T22:00:00-07:00",
    "values": {
      "humidity": 54.22,
      "pressureSeaLevel": 29.98,
      "temperature": 84.54,
      "windSpeed": 9.48
    }
  },
  {
    "startTime": "2021-10-05T23:00:00-07:00",
    "values": {
      "humidity": 57.34,
      "pressureSeaLevel": 29.95,
      "temperature": 84.09,
      "windSpeed": 9.82
    }
  },
  {
    "startTime": "2021-10-06T00:00:00-07:00",
    "values": {
      "humidity": 59.76,
      "pressureSeaLevel": 29.94,
      "temperature": 82.98,
      "windSpeed": 10.69
    }
  },
  {
    "startTime": "2021-10-06T01:00:00-07:00",
    "values": {
      "humidity": 62.74,
      "pressureSeaLevel": 29.94,
      "temperature": 81.41,
      "windSpeed": 11.19
    }
  },
  {
    "startTime": "2021-10-06T02:00:00-07:00",
    "values": {
      "humidity": 66.11,
      "pressureSeaLevel": 29.93,
      "temperature": 79.56,
      "windSpeed": 9.35
    }
  },
  {
    "startTime": "2021-10-06T03:00:00-07:00",
    "values": {
      "humidity": 73.23,
      "pressureSeaLevel": 29.94,
      "temperature": 77.16,
      "windSpeed": 6.93
    }
  },
  {
    "startTime": "2021-10-06T04:00:00-07:00",
    "values": {
      "humidity": 78.38,
      "pressureSeaLevel": 29.95,
      "temperature": 75.78,
      "windSpeed": 5.57
    }
  },
  {
    "startTime": "2021-10-06T05:00:00-07:00",
    "values": {
      "humidity": 82.25,
      "pressureSeaLevel": 29.97,
      "temperature": 74.68,
      "windSpeed": 5.06
    }
  },
  {
    "startTime": "2021-10-06T06:00:00-07:00",
    "values": {
      "humidity": 84.36,
      "pressureSeaLevel": 29.98,
      "temperature": 74.25,
      "windSpeed": 5.61
    }
  },
  {
    "startTime": "2021-10-06T07:00:00-07:00",
    "values": {
      "humidity": 85.82,
      "pressureSeaLevel": 29.98,
      "temperature": 73.94,
      "windSpeed": 5.88
    }
  },
  {
    "startTime": "2021-10-06T08:00:00-07:00",
    "values": {
      "humidity": 85.93,
      "pressureSeaLevel": 29.98,
      "temperature": 73.8,
      "windSpeed": 5.88
    }
  },
  {
    "startTime": "2021-10-06T09:00:00-07:00",
    "values": {
      "humidity": 85.96,
      "pressureSeaLevel": 29.96,
      "temperature": 73.62,
      "windSpeed": 5.75
    }
  },
  {
    "startTime": "2021-10-06T10:00:00-07:00",
    "values": {
      "humidity": 87.65,
      "pressureSeaLevel": 29.95,
      "temperature": 73.06,
      "windSpeed": 5.5
    }
  },
  {
    "startTime": "2021-10-06T11:00:00-07:00",
    "values": {
      "humidity": 89.24,
      "pressureSeaLevel": 29.94,
      "temperature": 72.54,
      "windSpeed": 5.28
    }
  },
  {
    "startTime": "2021-10-06T12:00:00-07:00",
    "values": {
      "humidity": 90.8,
      "pressureSeaLevel": 29.94,
      "temperature": 72.03,
      "windSpeed": 5.39
    }
  },
  {
    "startTime": "2021-10-06T13:00:00-07:00",
    "values": {
      "humidity": 91.06,
      "pressureSeaLevel": 29.93,
      "temperature": 71.92,
      "windSpeed": 5.46
    }
  },
  {
    "startTime": "2021-10-06T14:00:00-07:00",
    "values": {
      "humidity": 91.29,
      "pressureSeaLevel": 29.94,
      "temperature": 71.74,
      "windSpeed": 4.68
    }
  },
  {
    "startTime": "2021-10-06T15:00:00-07:00",
    "values": {
      "humidity": 92.02,
      "pressureSeaLevel": 29.95,
      "temperature": 71.44,
      "windSpeed": 4.21
    }
  },
  {
    "startTime": "2021-10-06T16:00:00-07:00",
    "values": {
      "humidity": 85.25,
      "pressureSeaLevel": 29.96,
      "temperature": 74.37,
      "windSpeed": 5.01
    }
  },
  {
    "startTime": "2021-10-06T17:00:00-07:00",
    "values": {
      "humidity": 75.52,
      "pressureSeaLevel": 29.97,
      "temperature": 78.37,
      "windSpeed": 6.58
    }
  },
  {
    "startTime": "2021-10-06T18:00:00-07:00",
    "values": {
      "humidity": 65.41,
      "pressureSeaLevel": 29.98,
      "temperature": 80.98,
      "windSpeed": 8.48
    }
  },
  {
    "startTime": "2021-10-06T19:00:00-07:00",
    "values": {
      "humidity": 60.58,
      "pressureSeaLevel": 29.98,
      "temperature": 82.83,
      "windSpeed": 8.34
    }
  },
  {
    "startTime": "2021-10-06T20:00:00-07:00",
    "values": {
      "humidity": 56.29,
      "pressureSeaLevel": 29.96,
      "temperature": 84.06,
      "windSpeed": 7.87
    }
  },
  {
    "startTime": "2021-10-06T21:00:00-07:00",
    "values": {
      "humidity": 53.19,
      "pressureSeaLevel": 29.94,
      "temperature": 85.03,
      "windSpeed": 7.56
    }
  },
  {
    "startTime": "2021-10-06T22:00:00-07:00",
    "values": {
      "humidity": 51.9,
      "pressureSeaLevel": 29.91,
      "temperature": 85.35,
      "windSpeed": 7.81
    }
  },
  {
    "startTime": "2021-10-06T23:00:00-07:00",
    "values": {
      "humidity": 52.68,
      "pressureSeaLevel": 29.9,
      "temperature": 84.78,
      "windSpeed": 8.7
    }
  },
  {
    "startTime": "2021-10-07T00:00:00-07:00",
    "values": {
      "humidity": 56.63,
      "pressureSeaLevel": 29.89,
      "temperature": 83.28,
      "windSpeed": 10.31
    }
  },
  {
    "startTime": "2021-10-07T01:00:00-07:00",
    "values": {
      "humidity": 64.74,
      "pressureSeaLevel": 29.9,
      "temperature": 81.16,
      "windSpeed": 10.92
    }
  },
  {
    "startTime": "2021-10-07T02:00:00-07:00",
    "values": {
      "humidity": 70.66,
      "pressureSeaLevel": 29.91,
      "temperature": 79.3,
      "windSpeed": 9.6
    }
  },
  {
    "startTime": "2021-10-07T03:00:00-07:00",
    "values": {
      "humidity": 78.17,
      "pressureSeaLevel": 29.92,
      "temperature": 77.18,
      "windSpeed": 7.63
    }
  },
  {
    "startTime": "2021-10-07T04:00:00-07:00",
    "values": {
      "humidity": 82.02,
      "pressureSeaLevel": 29.94,
      "temperature": 76.01,
      "windSpeed": 6.44
    }
  },
  {
    "startTime": "2021-10-07T05:00:00-07:00",
    "values": {
      "humidity": 83.44,
      "pressureSeaLevel": 29.94,
      "temperature": 75.4,
      "windSpeed": 6.67
    }
  },
  {
    "startTime": "2021-10-07T06:00:00-07:00",
    "values": {
      "humidity": 83,
      "pressureSeaLevel": 29.95,
      "temperature": 75.09,
      "windSpeed": 6.62
    }
  },
  {
    "startTime": "2021-10-07T07:00:00-07:00",
    "values": {
      "humidity": 82.25,
      "pressureSeaLevel": 29.95,
      "temperature": 75,
      "windSpeed": 6.35
    }
  },
  {
    "startTime": "2021-10-07T08:00:00-07:00",
    "values": {
      "humidity": 82.87,
      "pressureSeaLevel": 29.95,
      "temperature": 74.7,
      "windSpeed": 5.88
    }
  },
  {
    "startTime": "2021-10-07T09:00:00-07:00",
    "values": {
      "humidity": 83.85,
      "pressureSeaLevel": 29.93,
      "temperature": 74.35,
      "windSpeed": 5.68
    }
  },
  {
    "startTime": "2021-10-07T10:00:00-07:00",
    "values": {
      "humidity": 84.13,
      "pressureSeaLevel": 29.93,
      "temperature": 74.34,
      "windSpeed": 5.75
    }
  },
  {
    "startTime": "2021-10-07T11:00:00-07:00",
    "values": {
      "humidity": 83.25,
      "pressureSeaLevel": 29.92,
      "temperature": 74.61,
      "windSpeed": 5.5
    }
  },
  {
    "startTime": "2021-10-07T12:00:00-07:00",
    "values": {
      "humidity": 82.84,
      "pressureSeaLevel": 29.92,
      "temperature": 74.55,
      "windSpeed": 4.85
    }
  },
  {
    "startTime": "2021-10-07T13:00:00-07:00",
    "values": {
      "humidity": 83.09,
      "pressureSeaLevel": 29.92,
      "temperature": 74.37,
      "windSpeed": 4.63
    }
  },
  {
    "startTime": "2021-10-07T14:00:00-07:00",
    "values": {
      "humidity": 84.12,
      "pressureSeaLevel": 29.93,
      "temperature": 74.12,
      "windSpeed": 4.79
    }
  },
  {
    "startTime": "2021-10-07T15:00:00-07:00",
    "values": {
      "humidity": 84.76,
      "pressureSeaLevel": 29.94,
      "temperature": 73.74,
      "windSpeed": 4.3
    }
  },
  {
    "startTime": "2021-10-07T16:00:00-07:00",
    "values": {
      "humidity": 77.95,
      "pressureSeaLevel": 29.95,
      "temperature": 75.9,
      "windSpeed": 5.44
    }
  },
  {
    "startTime": "2021-10-07T17:00:00-07:00",
    "values": {
      "humidity": 65.99,
      "pressureSeaLevel": 29.96,
      "temperature": 79.23,
      "windSpeed": 8.23
    }
  },
  {
    "startTime": "2021-10-07T18:00:00-07:00",
    "values": {
      "humidity": 55.03,
      "pressureSeaLevel": 29.95,
      "temperature": 82.09,
      "windSpeed": 8.19
    }
  },
  {
    "startTime": "2021-10-07T19:00:00-07:00",
    "values": {
      "humidity": 50.38,
      "pressureSeaLevel": 29.95,
      "temperature": 84.04,
      "windSpeed": 9.26
    }
  },
  {
    "startTime": "2021-10-07T20:00:00-07:00",
    "values": {
      "humidity": 48.25,
      "pressureSeaLevel": 29.93,
      "temperature": 85.41,
      "windSpeed": 9.62
    }
  },
  {
    "startTime": "2021-10-07T21:00:00-07:00",
    "values": {
      "humidity": 48.8,
      "pressureSeaLevel": 29.92,
      "temperature": 85.91,
      "windSpeed": 9.89
    }
  },
  {
    "startTime": "2021-10-07T22:00:00-07:00",
    "values": {
      "humidity": 53.35,
      "pressureSeaLevel": 29.9,
      "temperature": 84.18,
      "windSpeed": 10.45
    }
  },
  {
    "startTime": "2021-10-07T23:00:00-07:00",
    "values": {
      "humidity": 54.34,
      "pressureSeaLevel": 29.89,
      "temperature": 84.02,
      "windSpeed": 10.49
    }
  },
  {
    "startTime": "2021-10-08T00:00:00-07:00",
    "values": {
      "humidity": 57.15,
      "pressureSeaLevel": 29.89,
      "temperature": 83.25,
      "windSpeed": 10.76
    }
  },
  {
    "startTime": "2021-10-08T01:00:00-07:00",
    "values": {
      "humidity": 63.89,
      "pressureSeaLevel": 29.9,
      "temperature": 81.09,
      "windSpeed": 9.91
    }
  },
  {
    "startTime": "2021-10-08T02:00:00-07:00",
    "values": {
      "humidity": 69.08,
      "pressureSeaLevel": 29.92,
      "temperature": 79.18,
      "windSpeed": 8.61
    }
  },
  {
    "startTime": "2021-10-08T03:00:00-07:00",
    "values": {
      "humidity": 72.11,
      "pressureSeaLevel": 29.93,
      "temperature": 77.9,
      "windSpeed": 6.62
    }
  },
  {
    "startTime": "2021-10-08T04:00:00-07:00",
    "values": {
      "humidity": 76.55,
      "pressureSeaLevel": 29.95,
      "temperature": 77,
      "windSpeed": 6.42
    }
  },
  {
    "startTime": "2021-10-08T05:00:00-07:00",
    "values": {
      "humidity": 83.19,
      "pressureSeaLevel": 29.95,
      "temperature": 75.74,
      "windSpeed": 7.38
    }
  },
  {
    "startTime": "2021-10-08T06:00:00-07:00",
    "values": {
      "humidity": 89.63,
      "pressureSeaLevel": 29.96,
      "temperature": 74.75,
      "windSpeed": 8.19
    }
  },
  {
    "startTime": "2021-10-08T07:00:00-07:00",
    "values": {
      "humidity": 90.56,
      "pressureSeaLevel": 29.96,
      "temperature": 74.52,
      "windSpeed": 7.63
    }
  },
  {
    "startTime": "2021-10-08T08:00:00-07:00",
    "values": {
      "humidity": 90.16,
      "pressureSeaLevel": 29.96,
      "temperature": 74.68,
      "windSpeed": 7.49
    }
  },
  {
    "startTime": "2021-10-08T09:00:00-07:00",
    "values": {
      "humidity": 88.92,
      "pressureSeaLevel": 29.96,
      "temperature": 74.93,
      "windSpeed": 8.52
    }
  },
  {
    "startTime": "2021-10-08T10:00:00-07:00",
    "values": {
      "humidity": 88.63,
      "pressureSeaLevel": 29.95,
      "temperature": 74.44,
      "windSpeed": 8.01
    }
  },
  {
    "startTime": "2021-10-08T11:00:00-07:00",
    "values": {
      "humidity": 88.47,
      "pressureSeaLevel": 29.95,
      "temperature": 74.32,
      "windSpeed": 7.78
    }
  },
  {
    "startTime": "2021-10-08T12:00:00-07:00",
    "values": {
      "humidity": 86.76,
      "pressureSeaLevel": 29.94,
      "temperature": 74.46,
      "windSpeed": 7.38
    }
  },
  {
    "startTime": "2021-10-08T13:00:00-07:00",
    "values": {
      "humidity": 88.4,
      "pressureSeaLevel": 29.94,
      "temperature": 74.3,
      "windSpeed": 7.18
    }
  },
  {
    "startTime": "2021-10-08T14:00:00-07:00",
    "values": {
      "humidity": 89.35,
      "pressureSeaLevel": 29.95,
      "temperature": 74.39,
      "windSpeed": 7.11
    }
  },
  {
    "startTime": "2021-10-08T15:00:00-07:00",
    "values": {
      "humidity": 90.07,
      "pressureSeaLevel": 29.96,
      "temperature": 74.32,
      "windSpeed": 6.85
    }
  },
  {
    "startTime": "2021-10-08T16:00:00-07:00",
    "values": {
      "humidity": 89.45,
      "pressureSeaLevel": 29.98,
      "temperature": 74.88,
      "windSpeed": 6.55
    }
  },
  {
    "startTime": "2021-10-08T17:00:00-07:00",
    "values": {
      "humidity": 87.87,
      "pressureSeaLevel": 29.99,
      "temperature": 75.83,
      "windSpeed": 7.49
    }
  },
  {
    "startTime": "2021-10-08T18:00:00-07:00",
    "values": {
      "humidity": 84.72,
      "pressureSeaLevel": 30,
      "temperature": 77.59,
      "windSpeed": 8.55
    }
  },
  {
    "startTime": "2021-10-08T19:00:00-07:00",
    "values": {
      "humidity": 76.99,
      "pressureSeaLevel": 29.99,
      "temperature": 79.16,
      "windSpeed": 9.28
    }
  },
  {
    "startTime": "2021-10-08T20:00:00-07:00",
    "values": {
      "humidity": 63.81,
      "pressureSeaLevel": 29.98,
      "temperature": 82.42,
      "windSpeed": 11.05
    }
  }
]
export default {
  weather,
  hours
}
